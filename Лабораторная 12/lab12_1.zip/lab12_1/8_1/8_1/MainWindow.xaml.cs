﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _8_1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void ComboBox_Loaded(object sender, RoutedEventArgs e)
        {
            // ... A List.
            List<string> data = new List<string>();
            data.Add("Theme1");
            data.Add("Theme2");

            // ... Get the ComboBox reference.
            var comboBox = sender as ComboBox;

            // ... Assign the ItemsSource to the List.
            comboBox.ItemsSource = data;

            // ... Make the first item selected.
            comboBox.SelectedIndex = 0;
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // ... Get the ComboBox.
            var comboBox = sender as ComboBox;

            // ... Set SelectedItem as Window Title.
            string value = comboBox.SelectedItem as string;
            this.Title = value;

            if (comboBox.SelectedIndex == 0)
            {
                var dict = new ResourceDictionary();
                string uriStr = "./Theme1.xaml";
                dict.Source = new Uri(uriStr, UriKind.RelativeOrAbsolute);
                MWindow.Resources.MergedDictionaries.Clear();
                MWindow.Resources.MergedDictionaries.Add(dict);
            }
            if (comboBox.SelectedIndex == 1)
            {
                var dict = new ResourceDictionary();
                string uriStr = "./Theme2.xaml";
                dict.Source = new Uri(uriStr, UriKind.RelativeOrAbsolute);
                MWindow.Resources.MergedDictionaries.Clear();
                MWindow.Resources.MergedDictionaries.Add(dict);
            }
        }
    }
}
